// background.js - Service Worker for Quran Radio Extension

const OFFSCREEN_DOCUMENT_PATH = 'offscreen.html';

async function ensureOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
  });

  if (existingContexts.length > 0) {
    return;
  }

  try {
    await chrome.offscreen.createDocument({
      url: OFFSCREEN_DOCUMENT_PATH,
      reasons: ['AUDIO_PLAYBACK'],
      justification: 'تشغيل بث القرآن الكريم في الخلفية'
    });
  } catch (error) {
    // Ignore race condition if offscreen document was just created
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target !== 'background') return;

  handleMessage(message)
    .then(sendResponse)
    .catch((err) => {
      sendResponse({ success: false, error: err.message });
    });

  return true;
});

async function handleMessage(message) {
  switch (message.action) {
    case 'play': {
      await ensureOffscreenDocument();
      const stored = await chrome.storage.local.get(['volume']);
      const volume = message.volume ?? stored.volume ?? 1.0;

      await chrome.storage.local.set({
        currentStation: message.stationIndex,
        currentUrl: message.url || '',
        volume
      });

      const res = await sendToOffscreen({
        action: 'play',
        url: message.url || '',
        fallbackUrls: message.fallbackUrls || [],
        tracks: message.tracks || [],
        archiveId: message.archiveId || '',
        stationIndex: message.stationIndex,
        volume
      });

      if (res && res.aborted) {
        return { success: false, aborted: true };
      }

      if (!res || !res.success) {
        await chrome.storage.local.set({ isPlaying: false });
        return {
          success: false,
          error: (res && res.error) || 'تعذر تشغيل المحطة'
        };
      }

      await chrome.storage.local.set({
        isPlaying: true,
        currentStation: message.stationIndex,
        currentUrl: message.url || ''
      });
      return { success: true };
    }

    case 'pause': {
      await ensureOffscreenDocument();
      await sendToOffscreen({ action: 'pause' });
      await chrome.storage.local.set({ isPlaying: false });
      return { success: true };
    }

    case 'setVolume': {
      const volume = Math.max(0, Math.min(1, Number(message.volume ?? 1.0)));
      await chrome.storage.local.set({ volume, volumeInitializedV2: true });
      await ensureOffscreenDocument();
      await sendToOffscreen({ action: 'setVolume', volume });
      return { success: true, volume };
    }

    case 'getState': {
      const state = await chrome.storage.local.get([
        'isPlaying',
        'currentStation',
        'volume',
        'currentUrl',
        'volumeInitializedV2'
      ]);

      if (!state.volumeInitializedV2) {
        state.volume = 1.0;
        await chrome.storage.local.set({ volume: 1.0, volumeInitializedV2: true });
      }

      return { success: true, state };
    }

    default:
      return { success: false, error: 'Unknown action' };
  }
}

async function sendToOffscreen(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ ...message, target: 'offscreen' }, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ success: false, ignored: true });
      } else {
        resolve(response);
      }
    });
  });
}

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get([
    'isPlaying',
    'currentStation',
    'volume',
    'currentUrl',
    'volumeInitializedV2'
  ]);

  await chrome.storage.local.set({
    isPlaying: existing.isPlaying ?? false,
    currentStation: existing.currentStation ?? 0,
    volume: existing.volumeInitializedV2 ? (existing.volume ?? 1.0) : 1.0,
    currentUrl: existing.currentUrl ?? '',
    volumeInitializedV2: true
  });
});
