// offscreen.js - Pure Live Radio Stream Player (24/7 Live Streams Only)

const audio = document.getElementById('quranAudio');

let currentPlayId = 0;
let stallTimer = null;
let currentVolume = 1.0;

function applyVolume(vol) {
  const clamped = Math.max(0, Math.min(1, Number(vol ?? 1)));
  currentVolume = clamped;
  audio.volume = clamped === 0 ? 0 : Math.min(1, Math.pow(clamped, 1.7));
}

applyVolume(1.0);

function clearStallTimer() {
  if (stallTimer) {
    clearTimeout(stallTimer);
    stallTimer = null;
  }
}

// Build candidate live stream URLs prioritizing fast direct live radio servers
function buildCandidateUrls(url, fallbackUrls = []) {
  const candidates = [];
  const addUrl = (u) => {
    if (!u || typeof u !== 'string') return;
    if (u.startsWith('mp3quran-server:')) return; // Strictly ignore any non-live server specs
    if (!candidates.includes(u)) {
      candidates.push(u);
    }
  };

  if (url && url.includes('://qurango.net/radio/')) {
    addUrl(url.replace('://qurango.net/radio/', '://backup.qurango.net/radio/'));
    addUrl(url);
  } else if (url && url.includes('://backup.qurango.net/radio/')) {
    addUrl(url);
    addUrl(url.replace('://backup.qurango.net/radio/', '://qurango.net/radio/'));
  } else if (url) {
    addUrl(url);
  }

  if (Array.isArray(fallbackUrls)) {
    fallbackUrls.forEach(addUrl);
  }

  return candidates;
}

// Fast, direct single-URL live stream playback attempt
function tryPlaySingleUrl(targetUrl, playId, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    if (playId !== currentPlayId) {
      return reject(new Error('ABORTED'));
    }

    let settled = false;

    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        reject(new Error('TIMEOUT'));
      }
    }, timeoutMs);

    audio.pause();
    applyVolume(currentVolume);

    audio.src = targetUrl;
    audio.load();

    audio
      .play()
      .then(() => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(true);
      })
      .catch((err) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(err);
      });
  });
}

async function playStation(url, volume, fallbackUrls = []) {
  const playId = ++currentPlayId;
  clearStallTimer();

  if (volume !== undefined && volume !== null) {
    applyVolume(volume);
  }

  const candidates = buildCandidateUrls(url, fallbackUrls);
  let lastError = null;

  for (const candidate of candidates) {
    if (playId !== currentPlayId) {
      return { success: false, aborted: true };
    }

    try {
      await tryPlaySingleUrl(candidate, playId, 5000);
      if (playId !== currentPlayId) {
        return { success: false, aborted: true };
      }
      return { success: true, activeUrl: candidate };
    } catch (err) {
      if (playId !== currentPlayId || (err && err.message === 'ABORTED')) {
        return { success: false, aborted: true };
      }
      lastError = err;
    }
  }

  // Final quick retry with cache-buster on primary live stream candidate
  if (candidates.length > 0 && playId === currentPlayId) {
    const primary = candidates[0];
    const retryUrl = primary.includes('serverkw.quran-uni.com')
      ? primary
      : primary + (primary.includes('?') ? '&' : '?') + '_t=' + Date.now();
    try {
      await tryPlaySingleUrl(retryUrl, playId, 5500);
      if (playId !== currentPlayId) {
        return { success: false, aborted: true };
      }
      return { success: true, activeUrl: retryUrl };
    } catch (err) {
      if (playId !== currentPlayId) {
        return { success: false, aborted: true };
      }
      lastError = err;
    }
  }

  return {
    success: false,
    error: (lastError && lastError.message) || 'Stream error'
  };
}

// Listen for messages from background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target !== 'offscreen') return;

  switch (message.action) {
    case 'play':
      playStation(message.url, message.volume, message.fallbackUrls)
        .then((res) => sendResponse(res))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true;

    case 'pause':
      currentPlayId++;
      clearStallTimer();
      audio.pause();
      sendResponse({ success: true });
      return true;

    case 'setVolume':
      applyVolume(message.volume);
      sendResponse({ success: true, volume: currentVolume });
      return true;

    case 'getAudioStatus':
      sendResponse({
        success: true,
        isPlaying: !audio.paused && !!audio.src,
        volume: currentVolume
      });
      return true;

    default:
      sendResponse({ success: false, error: 'Unknown action' });
      return true;
  }
});

// Handle mid-stream stalls safely without overriding a newly selected station
audio.addEventListener('stalled', () => {
  clearStallTimer();
  const stalledPlayId = currentPlayId;
  const stalledSrc = audio.src;

  stallTimer = setTimeout(() => {
    if (
      stalledPlayId === currentPlayId &&
      stalledSrc &&
      audio.src === stalledSrc &&
      !audio.paused &&
      audio.readyState < 3
    ) {
      audio.load();
      applyVolume(currentVolume);
      audio.play().catch(() => {});
    }
  }, 4000);
});